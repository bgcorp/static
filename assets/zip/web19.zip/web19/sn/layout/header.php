<?php
session_start();

if( !isset($_SESSION["session_username"]) ) {
header("location: sign_in.php"); }

?>

<!doctype html>
<html lang="ru">
<head>
	<title><?php echo $title; ?></title>
	
	<meta name="author" content="Bekzat">
	<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
	
	<link rel="stylesheet" type="text/css" href="css/static.css">
	<link rel="stylesheet" type="text/css" href="css/main.css">

	<link rel="icon" href="img/logo.ico" type="image/x-icon">
	
	<script type="text/javascript" src="js/jquery-3.3.1.min.js"></script>
	<script type="text/javascript" src="js/main.js"></script>
	<script type="text/javascript" src="js/sticky.js"></script>
	
</head>
<body>


<div id='navbar'>
<div class='navbar'>

<?php 
	$logo = "Bekzat";
	require_once 'control/connect.php';
?>

<span class='logo'><a href ='index.php' class='a_logo'> <?php echo $logo; ?> </a></span> 


<span class='top'> 
	<form method="get"  action="search.php" class="iblock"><input type="text" name="sname" class="spole" placeholder="Поиск"></form>
	<a href="index.php"> Моя страница </a>
	<a href="messages.php"> Чаты </a>
	<a href="settings.php"> Настройки </a>
	<a href="control/output.php"> Выйти </a>
</span>

</div>
</div>




<div class="content">