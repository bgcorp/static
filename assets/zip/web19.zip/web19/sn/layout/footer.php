</div>

<?php mysqli_close($link); ?>

<footer class='footer'> <?php echo $logo; ?> &nbsp; &#169; &nbsp; 2019 </footer>

</body>
</html>