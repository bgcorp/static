<?php

$query ="SELECT * FROM blog WHERE email='$semail' ORDER BY id DESC";
$result = mysqli_query($link, $query) ;

 while($row = $result->fetch_assoc())
    {
$idblog=$row['id'];
echo "<hr>
<div class='blog'>".$row['blog']."</div>

<a class='comments class_color'> 
Все комментарии </a><div class='tcomments'>";


$scomments ="SELECT * FROM comments WHERE blog='$idblog' ORDER BY id DESC";
$comments = mysqli_query($link, $scomments) ;


 while($rowc = $comments->fetch_assoc())
    {
echo "<hr><p class='class_color'>".$rowc['ufname']." ".$rowc['ulname']."
</p><p>".$rowc['comments']."</p>";
    }
    mysqli_free_result($comments);


echo "</div><a class='comments1 class_color'> 
Добавить комментарий </a>
<div class='tcomments1'>

<form method='get' action='control/add_like_co.php'>
<textarea name='comments' class='tarea' placeholder='Написать комментарий' required></textarea>
<input type='hidden' name='uemail' value='".$uemail."'>
<input type='hidden' name='email' value='".$semail."'>
<input type='hidden' name='fname' value='".$fname."'>
<input type='hidden' name='lname' value='".$lname."'>
<input type='hidden' name='idblog' value='".$row['id']."'><br>
<input type='submit' class='button' value='Добавить'></form>
</div>";






//like

echo "<div class='commentslike'>";
echo "<div class='likes'>";
$m=0;
$sqllike ="SELECT * FROM likes WHERE (blog='$idblog') AND (user='$uemail') ";
$like = mysqli_query($link, $sqllike) ;
 while($larow = $like->fetch_assoc())
 {
	$m=$larow['id'];
	if($larow['likes']==1){
echo "<form method='get' action='control/add_like_co.php'><input type='hidden' name='like' value='0'>
<input type='hidden' name='idblog' value='".$row['id']."'>
<button type='submit' class='like'>
 <image src='img/like.png' width='20' height='20'>
</button></form>";
	}
	
	else if ($larow['likes']==0){
echo "<form method='get' action='control/add_like_co.php'><input type='hidden' name='like' value='1'>
<input type='hidden' name='idblog' value='".$row['id']."'>
<button type='submit' class='like'>
<image src='img/alike.png' width='20' height='20'>
</button></form>";
    }
}
mysqli_free_result($like);



if($m==0){
echo "<form method='get' action='control/add_like_co.php'><input type='hidden' name='nlike' value='1'>
<input type='hidden' name='idblog' value='".$row['id']."'>
<button type='submit' class='like'>
<image src='img/alike.png' width='20' height='20'>
</button>
</form>";}




$sqllikes ="SELECT * FROM likes WHERE blog='$idblog' ";
$likes = mysqli_query($link, $sqllikes) ;
$slikes=0;
$sdislikes=0;
 while($lrow = $likes->fetch_assoc())
   {$slikes+=$lrow['likes']; 
    $sdislikes+=$lrow['dislikes']; }
	echo $slikes;
    mysqli_free_result($likes);
echo "</div>";



//dislike
echo "<div class='likes'>";
$n=0;
$sqllike ="SELECT * FROM likes WHERE (blog='$idblog') AND (user='$uemail') ";
$like = mysqli_query($link, $sqllike) ;
 while($larow = $like->fetch_assoc())
 {
	$n=$larow['id'];
	if($larow['dislikes']==1){
echo "<form method='get' action='control/add_like_co.php'><input type='hidden' name='dlike' value='0'>
<input type='hidden' name='idblog' value='".$row['id']."'>
<button type='submit' class='like'>
 <image src='img/adislike.png' width='20' height='20'>
</button></form>";
	}
	
	else if ($larow['dislikes']==0){
echo "<form method='get' action='control/add_like_co.php'><input type='hidden' name='dlike' value='1'>
<input type='hidden' name='idblog' value='".$row['id']."'>
<button type='submit' class='like'>
<image src='img/dislike.png' width='20' height='20'>
</button></form>";
    }
}
mysqli_free_result($like);


if($n==0){
echo "<form method='get' action='control/add_like_co.php'><input type='hidden' name='dnlike' value='1'>
<input type='hidden' name='idblog' value='".$row['id']."'>
<button type='submit' class='like'>
<image src='img/dislike.png' width='20' height='20'>
</button>
</form>";}


echo $sdislikes."</div>";

if($semail==$_SESSION['session_username']){

echo "<div style='margin-left: auto;'><form method='get'  action ='control/delete.php'>
<input type='hidden' name='iddel' value='".$row['id']."'>
<input type='submit' class='button' value='Удалить публикацию'></form>";
		echo "</div>";
		
}
    echo "</div>";
    }
mysqli_free_result($result);

?>