﻿<?php
	$title = "Чаты";
	include("layout/header.php");
?>


<div class="user">
<?php

if ( isset ($_GET['email']))
{  $_SESSION['semail']=$_GET['email'];}

$semail=$_SESSION['semail'];
$user=$_SESSION["session_username"];


$query ="SELECT * FROM user WHERE email='$semail'";
$result = mysqli_query($link, $query) ;

 while($row = $result->fetch_assoc())
    {
echo "<table><tr>";
echo "<form method='get' action='page.php'>
<input type='hidden' name='email' value='".$row['email']."'>";
echo "<td><img src='".$row['img']."' width='50' height='50'  style='border-radius: 50%;'></td><td>
<input type='submit' class='linkButton' 
value='".$row['firstname']." ".$row['lastname'].", ".$row['city']."'></td></form>";
echo "</tr></table></div>";
    }
	
    mysqli_free_result($result);
	
	

echo "<div class='messages' id='scroll'>"; 
$sqlmes ="SELECT * FROM messages WHERE 
(resuser='$semail' AND senduser='$user')  OR
(senduser='$semail' AND resuser='$user')
";
$mes = mysqli_query($link, $sqlmes) ;

 while($mrow = $mes->fetch_assoc())


    {  if ($mrow['senduser']==$user){
	echo  "<div class='senduser'>".$mrow['messages']."</div>";}
	else 
	{echo  "<div class='resuser'>".$mrow['messages']."</div>";}
    }
	
    mysqli_free_result($mes);

date_default_timezone_set('Asia/Almaty');
$date=date("Y-m-d G:i:s");

echo  "</div>";
 
echo "<div class='ok'> 
<form method='get'> 
<input type='hidden' name='senduser' value='".$_SESSION["session_username"]."'>
<input type='hidden' name='resuser' value='".$semail."'>
<input type='hidden' name='date' value='".$date."'>

<input type='text' name='messages' class='mpole' required placeholder='Написать сообщение'>
<input type='submit' value='Отправить' class='mbutton'>
</div>";


if(isset($_GET['messages']))
{
	$senduser=$_GET['senduser'];
	$resuser=$_GET['resuser'];
	$date=$_GET['date'];
	$messages=$_GET['messages'];
	
$sqlmess="INSERT INTO messages (senduser,resuser,date,messages) 
	VALUES ('$senduser','$resuser','$date','$messages')";
	$mess = mysqli_query($link,$sqlmess);
	if ($mess == true){ 
	$_SESSION['memail'] = $_GET['resuser']; 
	
    header("location: message.php");

    unset($_GET['messages']);
    }else{
    	echo "Произошла ошибка";
    }
}


?>

<script> 
window.onload = function(){
  document.getElementById('scroll').scrollTop = 9999;
}


</script>

</div>



 <?php
	include("layout/footer.php");
?>