
$(document).ready(function(){
	
	$('.tblog').hide();
    $('#btn_t_publication').click(function(){
    $(this).next().toggle(600)});
	
	$('.tblogimg').hide();
    $('.bbuttonimg').click(function(){
    $(this).next().toggle(600)});
	
	$('.tcomments1').hide();
	$('.comments1').click(function(){
    $(this).next().toggle(400)});
	
	$('.tcomments').hide();
	$('.comments').click(function(){
    $(this).next().toggle(400)});

	
	
	
	
	/*
	window.onscroll = function() {myFunction()};
	var menu = document.getElementById("menu");
	var sticky = menu.offsetTop;
	function myFunction() {
		if (window.pageYOffset >= sticky) { menu.classList.add("sticky") } 
		else { menu.classList.remove("sticky"); }}
	*/

});




