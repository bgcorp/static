﻿<?php
	$title = "Моя страница";
	include("layout/header.php");
?>




<div class="inf">
<?php

$email=$_SESSION['session_username'];
$semail=$_SESSION['session_username'];
$uemail=$_SESSION['session_username'];



if(isset($email)){
$query ="SELECT * FROM user WHERE email='$email'";
$result = mysqli_query($link, $query) ;

 while($row = $result->fetch_assoc()) {
	 $fname=$row['firstname'];
	 $lname=$row['lastname'];
	 $row['birth'] = date_format(date_create($row['birth']), 'd.m.Y');

echo "<div class='img'><img src='".$row['img']."' width='160' height='155'  style='border-radius: 50%;'>
</div>
<div class='img1'>
<p style='font-size: 20px;'> ".$row['firstname']." ".$row['lastname']."<p>
<p>Дата рождения: ".$row['birth']."</p>
<p>Город: ".$row['city']." <p>";



echo "</div>";

    }
}


?>


</div>



<div class="inf1">
<a class='button' id='btn_t_publication'> Добавить публикацию </a>

<div class='tblog'> 

<form method='get' action='control/addblog.php'>Запись
	<p><textarea name='blog' class='tarea' required placeholder='Напишите'></textarea></p>
	<p><input type='submit' value='Добавить' class='button'></p>
</form>


<form method='get' action='control/addblog.php'>Или фотографию
	<p><input type="text" name="imgpubl"  required placeholder="Введите название фото" class="pole"></p>
	<p><input type='submit' value='Добавить' class='button'></p>
</form>

</div>
</div>

<?php include "layout/publication.php";  ?>

</div>



 <?php
	include("layout/footer.php");
?>
