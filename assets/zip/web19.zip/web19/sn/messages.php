﻿<?php
	$title = "Чаты";
	include("layout/header.php");
?>

<p style='color:#3897f0; font-size: 25px; text-align: center;'> Чаты </p>

<?php

if ( isset ($_SESSION['memail']))
{   unset($_SESSION['memail']);}

if ( isset ($_SESSION['semail']))
{  unset($_SESSION['semail']);}

$user=$_SESSION["session_username"];


$sqlmes ="SELECT  DISTINCT resuser, senduser,messages
FROM messages WHERE 
(senduser='$user')  OR (resuser='$user')  ORDER BY date DESC 

" ;

$mes = mysqli_query($link, $sqlmes) ;

 while($mrow = $mes->fetch_assoc())
 {
	 
if(isset($user2)&&($user2!=$mrow['senduser'])&&($user2!=$mrow['resuser']))
{
if($user!=$mrow['senduser']) {

$user2=$mrow['senduser'];
}
else if ($user!=$mrow['resuser']) { $user2=$mrow['resuser']; }

$query ="SELECT * FROM user WHERE email='$user2'";
$result = mysqli_query($link, $query) ;

 while($row = $result->fetch_assoc())
    {
echo "<div class='user1'><table><tr>";
echo "<form method='get' action='message.php'>
<input type='hidden' name='email' value='".$user2."'>";
echo "<td><img src='".$row['img']."' width='50' height='50' style='border-radius: 50%;'></td><td>
<input type='submit' class='linkButton' 
value='".$row['firstname']." ".$row['lastname'].", ".$row['city']."'></td></form>";

echo "</tr><tr> <td> </td> <td> ".$mrow['messages']." </td></tr></table> </div>";

    
	}	
    mysqli_free_result($result);
 } 
 
 
 
 
 if(!isset($user2))
{
if($user!=$mrow['senduser']) {

$user2=$mrow['senduser'];
}
else if ($user!=$mrow['resuser']) { $user2=$mrow['resuser']; }

$query ="SELECT * FROM user WHERE email='$user2'";
$result = mysqli_query($link, $query) ;

 while($row = $result->fetch_assoc())
    {
echo "<div class='user1'><table><tr>";
echo "<form method='get' action='message.php'>
<input type='hidden' name='email' value='".$user2."'>";
echo "<td><img src='".$row['img']."' width='50' height='50' style='border-radius: 50%;'></td><td>
<input type='submit' class='linkButton' 
value='".$row['firstname']." ".$row['lastname'].", ".$row['city']."'></td></form>";

echo "</tr><tr> <td> </td> <td> ".$mrow['messages']." </td></tr></table> </div>";

    
	}	
    mysqli_free_result($result);
 } 
 
 
}
mysqli_free_result($mes);


?>



 <?php
	include("layout/footer.php");
?>