﻿<?php	session_start();
	if(isset($_SESSION["session_username"])){
		header("location: index.php");
	}
	
?>


<!doctype html>
<html lang="ru">
<head>
	<title> Регистрация </title>
	
	<meta name="author" content="Bekzat">
	<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
	
	<link rel="stylesheet" type="text/css" href="css/login.css">

	<link rel="icon" href="img/logo.ico" type="image/x-icon">

</head>
<body>

<div class='sign_in' id='sign_in'>
	<div class='div_logo'>Bekzat</div> 

<form method="POST">

  
    <div class='div_input'>
    <input type="text" name="firstname" maxlength="30" class="pole" placeholder="Имя" required autofocus/>

  </div>
  
    <div class='div_input'>
    <input type="text" name="lastname" maxlength="30" class="pole" placeholder="Фамилия" required/>
  </div>
  
    <div class='div_input'>
    <input type="text" name="city" maxlength="30" class="pole" placeholder="Город" required/>
  </div>

  <div class='div_input'>
    <input type="date" name="birth" maxlength="30" class="pole" placeholder="Дата рождения" required/>
  </div>

<div class='div_input'>
    <input type="email" name="email" maxlength="30" class="pole" placeholder="Эл. адрес" required/>
   
  </div>

<div class='div_input'>
    <input name="password" type="password" maxlength="50" minlength="8" class="pole" required placeholder="Придумайте пароль"/>

  </div>
  
<div class='div_input'>
<button class="button" type="submit" id="btn_sign_up">Регистрация</button>
  </div>
  
</form>


<?php

if (isset($_POST['firstname']) && isset($_POST['lastname'])
	&& isset($_POST['email'])&& isset($_POST['password'])&&isset($_POST['city'])){
		
    $firstname = $_POST['firstname'];
    $lastname = $_POST['lastname'];
	$city = $_POST['city'];
	$birth = $_POST['birth'];
	$email = $_POST['email'];
    $password = $_POST['password'];
	
$strong=0;

if(preg_match("/([0-9]+)/", $password))
        {
            $strong++;
        }
        else
            echo '<p style="margin: 0;text-align: center;">Не хватает цифр</p>';
        if(preg_match("/([a-z]+)/", $password))
        {
            $strong++;
           
        }
        else
            echo '<p style="margin: 0;text-align: center;">Не хватает маленьких букв</p>';
        if(preg_match("/([A-Z]+)/", $password))
        {
            $strong++;
        }
        else
            echo '<p style="margin: 0;text-align: center;">Не хватает больших букв</p>';
        if(preg_match("/\W/", $password))
        { 
            $strong++;
        }

if($strong>=3){
	require_once 'control/connect.php'; 
	
    $sql="INSERT INTO user (firstname,lastname,city,birth,email,password) 
	VALUES ('$firstname','$lastname','$city','$birth','$email','$password')";
    $sav = mysqli_query($link,$sql);

    if ($sav == true){
    if(!empty($email) && !empty($password)) {
	$email=htmlspecialchars($email);
	$password=htmlspecialchars($password);
$query ="SELECT * FROM user WHERE email='".$email."' AND password='".$password."'";
	$result = mysqli_query($link,$query);
	$numrows=mysqli_num_rows($result);
	if($numrows!=0)
 {
while($row= $result->fetch_assoc())
 {
	$dbusername=$row['email'];
	$dbpassword=$row['password'];
	$firstname=$row['firstname'];
	$lastname=$row['lastname'];
	$city=$row['city'];
 }
  if($email == $dbusername && $password == $dbpassword)
 { $_SESSION['session_username']=$email;
    header("Location: index.php"); }
	}
    }
}
	else{
    	echo "<p style='color:#EE3B3B; margin: 0;text-align: center;'>Данный эл. адрес занят</p>";
    }
	mysqli_close($link);
	}
	}
?>


  <div class='div_oth'>
  <p>Есть аккаунт? <a href="sign_in.php"> Вход </a></p>
  </div>
  
  <div class='div_oth' id='incorrect'>Неверный емаил или пароль</div>
  
<div class="spinner">
	<div class="bounce1"></div>
	<div class="bounce2"></div>
	<div class="bounce3"></div>
</div>

<div class="process"><div class="process_spinner">
  <div class="bounce1"></div>
  <div class="bounce2"></div>
  <div class="bounce3"></div>
</div></div>


</div>

<script type="text/javascript" src="js/jquery-3.3.1.min.js"></script>
<script type="text/javascript" src="js/login.js"></script>
</body>
</html>