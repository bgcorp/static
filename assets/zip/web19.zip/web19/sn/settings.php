﻿<?php
	$title = "Настройки";
	include("layout/header.php");
?>


<div class="settings">

<p style='font-size: 20px;'> Личная информация</p><hr>
<p> Ваше фото: </p>


<?php

$email=$_SESSION['session_username'];


$query ="SELECT * FROM user WHERE email='$email'";
$set = mysqli_query($link, $query) ;

 while($row = $set->fetch_assoc())
    {
$row['birth'] = date_format(date_create($row['birth']), 'd.m.Y');


echo "<img src='".$row['img']."' width='160' height='155'  style='border-radius: 50%;'>

<p> Ваше имя: ".$row['firstname']. "</p>
<p> Ваша фамилия: " .$row['lastname']. "</p>
<p> Город: " .$row['city']. "</p>
<p> Дата рождения: " .$row['birth']. "</p>
<p> Ваш email: " .$row['email']. "</p>";

$city=$row['city'];

$queryci ="SELECT * FROM city WHERE city='$city'";
$resultci = mysqli_query($link, $queryci) ;

 while($ci = $resultci->fetch_assoc()){
		$cia = $ci['id'];
	}
	mysqli_free_result($resultci);
    }

mysqli_free_result($set);


if(!isset($cia)) {$cia=162;}
?>

<a href="https://clck.yandex.ru/redir/dtype=stred/pid=7/cid=1228/*https://yandex.kz/pogoda/<?php echo $cia; ?>" 
target="_blank" border="0" >
<img src="https://info.weather.yandex.net/<?php echo $cia; ?>/3_white.ru.png?domain=ua" border="0" alt="Погода" />
</a>

<hr>
<p>Добавить фотографию:</p>
<form method="get" action="settings.php">
<input type="text" name="img"  required placeholder="Введите название фото" class="pole">
<input type="submit" class="button" value="Добавить">
</form>

<?php

if (isset($_GET['img'])){

	$img = "img/".$_GET['img'];
	
    $iquery="UPDATE user SET  img='$img' WHERE email='$email'";
    $ires = mysqli_query($link,$iquery);
	
    if ($ires == true){
header("location:settings.php");
    }else{
    	echo "<p style='color:#EE3B3B;'>Ошибка</p>";
    }
mysqli_close($link);
}
?>

<p>Изменение пароля:</p>
<form method="post" action="settings.php">
<input type="password" name="password" minlength="8" required placeholder="Введите новый пароль" class="pole">
<input type="submit" class="button" value="Изменить">
</form>

<?php

if (isset($_POST['password'])){
	$strong=0;
	$password = $_POST['password'];

if(preg_match("/([0-9]+)/", $password))
        {
            $strong++;
        }
        else
            echo 'Не хватает цифр<br />';
        if(preg_match("/([a-z]+)/", $password))
        {
$strong++;
        }
        else
            echo 'Не хватает маленьких букв<br />';
        if(preg_match("/([A-Z]+)/", $password))
        {
$strong++;
        }
        else
            echo 'Не хватает больших букв<br />';
        if(preg_match("/\W/", $password))
        { 
$strong++;
        }

if($strong>=3){


	
    $query="UPDATE user SET  password='$password' WHERE email='$email'";
    $res = mysqli_query($link,$query);
	
    if ($res == true){
 echo "<p style='color: #4F94CD;'>Пароль успешно изменен</p>";
    }else{
    	echo "<p style='color:#EE3B3B;'>Ошибка</p>";
    }

}
}
?>

</div>



 <?php
	include("layout/footer.php");
?>