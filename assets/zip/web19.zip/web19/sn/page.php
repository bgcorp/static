﻿<?php
	$title = "Страница";
	include("layout/header.php");
?>


<div class="inf">



<?php
$email=$_SESSION['session_username'];

$query1 ="SELECT * FROM user WHERE email='$email'";
$userp = mysqli_query($link, $query1) ;
	
 while($row1 = $userp->fetch_assoc())
    {
$fname=$row1['firstname'];
$lname=$row1['lastname'];
    }
mysqli_free_result($userp);





if(isset($_GET['email'])){ $semail=$_GET['email'] ;
$_SESSION['semail']=$_GET['email'];}

else{
$semail=$_SESSION['semail'];}

$uemail=$_SESSION['session_username'];

$m=0;

//user

$query ="SELECT * FROM user WHERE email='$semail'";
$result = mysqli_query($link, $query) ;
$abons = array();
	
 while($row = $result->fetch_assoc())
    {
$row['birth'] = date_format(date_create($row['birth']), 'd.m.Y');

echo "<div class='img'><img src='".$row['img']."' width='160' height='155'  style='border-radius: 50%;'>
</div>


<div class='img1'>
<p> <font size='5px'> ".$row['firstname']." ".$row['lastname']."</font><p>
<p>Дата рождения: ".$row['birth']."</p>
<p> Город: ".$row['city']." </p>

<form method='get' action='message.php'>
<input type='hidden' name='email' value='".$row['email']."'>
<p><input type='submit' class='button'  value='Написать'></p></form></div></div>";


    }
    mysqli_free_result($result);

?>

<?php include "layout/publication.php";  ?>
</div>
</div>


 <?php
	include("layout/footer.php");
?>