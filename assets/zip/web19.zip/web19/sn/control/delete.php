<?php

require_once 'connect.php'; 
	
	if(isset($_GET['iddel']))
	{
    $iddel=$_GET['iddel'];
	echo $iddel;

	$deletesql ="DELETE FROM blog WHERE id = '$iddel'";
	$result = mysqli_query($link,$deletesql);
    if ($result == true){
    echo "<script>history.go(-1)</script>";
    }else{
    	echo "Произошла ошибка";
    }
	}
	
?>