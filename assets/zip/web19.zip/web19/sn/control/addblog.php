<?php
session_start();

require_once 'connect.php'; 

if(!isset($_SESSION["session_username"])):
header("location:index.php");
else:

	if (isset($_GET['blog']) ){
	$blog = $_GET['blog'];
    $email=$_SESSION["session_username"];

    $queryb="INSERT INTO blog (email, blog) 
	VALUES ('$email','$blog')";
	$sav = mysqli_query($link,$queryb);
    
	if ($sav == true){
header("location:../index.php");
    }
	}
	
	if (isset($_GET['imgpubl']) ){
	$a=$_GET['imgpubl'];
	$blog = '<img src ="img/'.$a.'" width="100%" heigth="100%">';
	
    $email=$_SESSION["session_username"];

    $queryb="INSERT INTO blog (email, blog) 
	VALUES ('$email','$blog')";
	$sav = mysqli_query($link,$queryb);
    
	if ($sav == true){
header("location:../index.php");
    }
	}
	endif;
	?>