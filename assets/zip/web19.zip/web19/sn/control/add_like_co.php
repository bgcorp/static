<?php
session_start();

if(!isset($_SESSION["session_username"])) {
header("location: sign_in.php"); }

$uemail=$_SESSION['session_username'];

require_once 'connect.php'; 

if (isset($_GET['comments']) ){
	$comments = $_GET['comments'];
	$idblog = $_GET['idblog'];
    $uemail = $_GET['uemail'];
	$fname = $_GET['fname'];
	$lname= $_GET['lname'];
	$uemail = $_GET['email'];
	
	$comm="INSERT INTO comments (blog,email,ufname,ulname, comments) 
	VALUES ('$idblog','$uemail','$fname','$lname','$comments')";
	$c = mysqli_query($link,$comm);
	
    if ($c == true){echo "<script>history.go(-1)</script>";}
	else{ echo "Error";}
}


if (isset($_GET['like'])){
    $alike = $_GET['like'];
	$idbloga = $_GET['idblog'];
	
    $asqllike="UPDATE likes SET  likes ='$alike' WHERE blog='$idbloga' AND user='$uemail' ";
    $blike = mysqli_query($link,$asqllike);
	
    if ($blike == true){
	echo "<script>history.go(-1)</script>";}
	else{ echo "Error";}
}



if (isset($_GET['nlike']) ){
	$nlike = $_GET['nlike'];
	$idblog = $_GET['idblog'];
	
	
    $nlikes="INSERT INTO likes (likes,blog,user) 
	VALUES ('$nlike','$idblog','$uemail')";
	$n = mysqli_query($link,$nlikes);
	
	if ($n == true) {echo "<script>history.go(-1)</script>";}
	else{ echo "Error";}

}


if (isset($_GET['dlike'])){
    $alike = $_GET['dlike'];
	$idbloga = $_GET['idblog'];
	
    $asqllike="UPDATE likes SET  dislikes ='$alike' WHERE blog='$idbloga' AND user='$uemail' ";
    $blike = mysqli_query($link,$asqllike);
	
    if ($blike == true){
	echo "<script>history.go(-1)</script>";}
	else{ echo "Error";}
}



if (isset($_GET['dnlike']) ){
	$nlike = $_GET['dnlike'];
	$idblog = $_GET['idblog'];
	
	
    $nlikes="INSERT INTO likes (dislikes,blog,user) 
	VALUES ('$nlike','$idblog','$uemail')";
	$n = mysqli_query($link,$nlikes);
	
	if ($n == true) {echo "<script>history.go(-1)</script>";}
	else{ echo "Error";}

}

?>