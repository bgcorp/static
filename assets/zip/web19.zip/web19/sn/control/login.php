<?php
session_start();


if (isset($_POST['email'])) {

	require_once 'connect.php'; 
	
	$email=htmlspecialchars($_POST['email']);
	$password=htmlspecialchars($_POST['password']);
	
	$query ="SELECT * FROM user WHERE email='".$email."' AND password='".$password."'";
	$result = mysqli_query($link,$query);
	$numrows=mysqli_num_rows($result);
	
	if($numrows!=0){
	while($row= $result->fetch_assoc()){
		$dbusername=$row['email'];
		$dbpassword=$row['password'];	}
  
  
	if($email == $dbusername && $password == $dbpassword){
		$_SESSION['session_username']=$email;
		echo json_encode(array('success' => 1));	}
	} 
	else {
		echo json_encode(array('success' => 0));	}
} 


else {
    echo json_encode(array('success' => 0));
}



?>