﻿<?php
	$title = "Поиск";
	include("layout/header.php");
?>


<style>
table{
	border: 1px solid #e0e0e0;
	border-radius:  4px;
	width: 70%;
	margin: auto;
	padding: 5px;
}

table:hover
{background-color: #fafafa;}

</style>



<?php

if ( isset ($_SESSION['semail']))
{  unset($_SESSION['semail']);}


echo "
<p style=' text-align: center; margin: 0; padding: 20px 0;'> 
Результаты по запросу: '". $_GET['sname']."'</p>";

$sname=$_GET['sname'];

$query ="SELECT * FROM user WHERE firstname='$sname'";
$result = mysqli_query($link, $query) ;
$abons = array();
{
    $rows = mysqli_num_rows($result); 

	
 while($row = $result->fetch_assoc())
    {
	if($row['email']!=$_SESSION['session_username']){
echo "<table><tr>";
echo "<form method='get' action='page.php'>
<input type='hidden' name='email' value='".$row['email']."'>";
echo "<td><img src='".$row['img']."' width='50' height='50' style='border-radius: 50%;'></td><td>
<input type='submit' class='linkButton' 
value='".$row['firstname']." ".$row['lastname'].", ".$row['city']."'></td></form>";

echo "</tr></table>";
    }
	}
    mysqli_free_result($result);
}
 

?>



 <?php
	include("layout/footer.php");
?>