$(document).ready(function(){
	$('.process').hide();
	$('.spinner').hide();
	$('#incorrect').hide();

	
	$('#btn_sign_in').click(function(){
		$('.spinner').show();
		
		var email = $('#email').val();
		var password = $('#password').val();

		$.ajax({
			type: "POST",
			url: "control/login.php",
			data: {"email":email, "password":password},
		error: function() {
			$('.spinner').hide();
			alert('Неполадки сетью');
		},
		success: function(response) {
			$('.spinner').hide();

			var jsonData = JSON.parse(response);
			if (jsonData.success == "1"){
                    location.reload();
                }
            else{
					$('#incorrect').show();
                }
			}
		});
	});
	
	
	
});