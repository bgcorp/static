<?php
	session_start();
	$logo = "<span class='logo'><a href ='index.php' class='a_logo'> Shop </a></span>";
?>

<!doctype html>
<html lang="ru">
<head>
	<title><?php echo $title; ?></title>

	<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">

	<link  type="text/css" rel="stylesheet" href="css/main.css">
	<link  type="text/css" rel="stylesheet" href="css/static.css">
	<link  type="text/css" rel="stylesheet" href="css/checkmark.css">
	
	<link rel="icon" href="image/logo.ico" type="image/x-icon">
	
	<script type="text/javascript" src="js/jquery-3.3.1.min.js"></script>

</head>
<body>




<?php
 require_once 'control/connect.php'; 
 
 if(isset($_SESSION["id_user"])){
	 $id_user=$_SESSION["id_user"];
	 $k=0;
	 $select_query ="select * from cart_goods where id_user='$id_user'";
	 $res = mysqli_query($link, $select_query) ;
	 
	 while($row = $res->fetch_assoc()){
			 $k++;
		}
    mysqli_free_result($res);
	
	$select_query ="select * from users where id_user='$id_user'";
	$res = mysqli_query($link, $select_query) ;
	
	while($row = $res->fetch_assoc()){
		$status = $row['status'];
	}
}
?>



<div id='navbar'>
<div class='navbar'>

	<?php echo $logo; ?>
	<span class="top">
		<a href="index.php" class="a_header"> Главная  </a>
		<?php 
		if( isset($_SESSION["id_user"]) ){
			if( $status == "admin")
				echo "<a href='admin.php' class='a_header'> Страница администратора </a>";
		}
		?> 
	
	<?php
		if( isset($_SESSION["id_user"]) ){
			echo "<a href ='my_purchases.php' class='cart'>История покупок</a>";
		}
	?> 
		<a href ="my_cart.php" class="cart"> Корзина <span id="cartcount"><?php if(isset($k)) {echo $k;} ?> </span></a>
		<?php 
			if( !isset($_SESSION["id_user"]) )
				echo "<a href ='sign_in.php' class='a_header'> Вход </a>"; 
			else echo "<a href='control/sign_out.php' class='a_header'> Выйти </a>"; ?> 
	</span>

</div>
</div>


<div class="content">