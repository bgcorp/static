</div>

<?php mysqli_close($link); ?>

<div class="footer">
	<span class="footer_span"> <?php echo $logo; ?> </span>
	<span class="footer_span">  Мы принимает платежи </span>
	<span class="footer_pay"> VISA</span>
	<span class="footer_pay"> MasterCard</span>
</div>

<script type="text/javascript" src="js/sticky.js"></script>
</body>
</html>