﻿<?php
	$title = "Мои покупки";
	include("layout/header.php");
?>


<?php
if( !isset($_SESSION["id_user"]) )
	header("location:sign_in.php");
?>

<div class="block_name"> История покупок </div>
<div class="goods_block">


<?php
	$id_user=$_SESSION["id_user"];
	$query ="SELECT * FROM sold_goods where id_user='$id_user' ORDER BY date DESC";
	
	$result = mysqli_query($link, $query);
	
	while( $row = $result->fetch_assoc() ) {
		
		$nds=(12*$row['price'])/100;
		
		echo "<div class='chek'><p class='margin5 goods_price text_align'> Shop </p>
		<p class='text_align'> Продажа № ".$row['id']." </p>
		<p class='text_align'> Онлайн покупка на сайте Shop </p><hr>
		<p> Покупка на сумму: ".$row['price'].".00 тг</p>
		<p> В т. ч. НДС 12%: ".$nds." тг </p>
		<p> Дата: ".$row['date']." </p>
		<p> Электронный чек № ".$row['id']." </p><hr>
		<p class='text_align'> Спасибо за покупку! </p></div>";
}
	
    mysqli_free_result($result);

?>
</div>



 <?php
	include("layout/footer.php");
?>