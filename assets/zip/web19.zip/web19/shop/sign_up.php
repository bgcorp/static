<?php	session_start();
	if( isset($_SESSION['id_user']) )
		header("location: index.php");
?>


<!doctype html>
<html lang="ru">
<head>
	<title>Shop | Регистрация </title>

	<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

	<link rel="stylesheet" type="text/css" href="css/login.css">
	
	<link rel="icon" href="image/logo.ico" type="image/x-icon">

</head>
<body>






<div class='sign_in' id='sign_in'>
	<div class='div_logo'> Shop </div> 

<form method="POST">

    <div class='div_input'>
		<input type="text" name="firstname" maxlength="30" class="pole" placeholder="Имя" required autofocus/>
	</div>
  
    <div class='div_input'>
		<input type="text" name="lastname" maxlength="30" class="pole" placeholder="Фамилия" required/>
	</div>
  

	<div class='div_input'>
		<input type="email" name="email" maxlength="30" class="pole" placeholder="Эл. адрес" required/>
	</div>

	<div class='div_input'>
		<input name="password" type="password" maxlength="50" minlength="8" class="pole" required placeholder="Придумайте пароль"/>
	</div>
  
	<div class='div_input'>
		<button class="button" type="submit" id="btn_sign_up">Регистрация</button>
	</div>
  
</form>

	<div class='div_oth'>
		<p>Есть аккаунт? <a href="sign_in.php"> Вход </a></p>
		<p> <a href="index.php"> На главную страницу </a></p>
	</div>



<?php

if (isset($_POST['firstname']) && isset($_POST['lastname'])
	&& isset($_POST['email'])&& isset($_POST['password'])){

    $firstname = $_POST['firstname'];
    $lastname = $_POST['lastname'];
	$email = $_POST['email'];
    $password = $_POST['password'];
    
	require_once 'control/connect.php'; 
	
    $query="INSERT INTO users (firstname, lastname, email, password) 
	VALUES ('$firstname','$lastname','$email','$password')";
    $sav = mysqli_query($link,$query);
	
    if ($sav == true){
		$s_query = "select * from users where email='$email'";
		$s_result = mysqli_query($link, $s_query);
	
		while($row = $s_result->fetch_assoc()){
			$id_user = $row['id_user'];
		}
	$_SESSION['id_user']=$id_user;

    header("location: index.php");
    }else{
    	echo "<p style='color:#EE3B3B;'> Данный email уже использовался </p>";
    }
}
?>

 </div>
 
 
 
 </body>
</html>