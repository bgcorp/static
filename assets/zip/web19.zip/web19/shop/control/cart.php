<?php
session_start();

if (isset($_GET['id_goods']) ){

    $id_goods = $_GET['id_goods'];
	$id_user=$_SESSION["id_user"];
    $date_cart = $_GET['date'];
	
	require_once 'connect.php'; 
	
	$s_query = "select * from goods where id_goods='$id_goods'";
    $s_result = mysqli_query($link, $s_query);
	
	while($rowgoods = $s_result->fetch_assoc()){
		$name_goods = $rowgoods['name_goods'];
		$price_goods = $rowgoods['price_goods'];
	}
	
	
    $addcart_query="INSERT INTO cart_goods (id_user, name_goods, price_goods, date) 
	VALUES ('$id_user', '$name_goods', $price_goods, '$date_cart')";
    $addcart_result = mysqli_query($link,$addcart_query);

	 $k=0;
	 $select_query_count ="select * from cart_goods where id_user='$id_user'";
	 $result_count = mysqli_query($link, $select_query_count) ;
	 
	 while($row = $result_count->fetch_assoc()){
			 $k++;
		}
	echo $k;

}
?>


