<?php
header('Content-Type: text/html; charset=utf-8');

$db_host = "localhost"; 
$db_user = "root"; 
$db_password = "root"; 
$db_base = "db_shop_php"; 

$link = mysqli_connect($db_host, $db_user, $db_password, $db_base) 
    or die("Ошибка " . mysqli_error($link)); 
mysqli_set_charset($link, "utf8");
?>