﻿<?php
session_start();

if (isset($_POST['id_card'])&&$_POST['sum']!=0){

	$price = $_POST['sum'];
	$date = $_POST['date'];
    $card = $_POST['id_card'];
	$id_user=$_SESSION['id_user'];

	require_once 'connect.php'; 
	
    $query="INSERT INTO sold_goods (id_user, price, card, date) 
	VALUES ('$id_user','$price','$card','$date')";
    $buy = mysqli_query($link,$query);
	
    if ( $buy == true ) {header( "location: ../my_purchases.php" ); }
	
    else { header( "location: ../my_cart.php" ); }
}

else { header( "location: ../my_cart.php" ); }
?>