﻿<?php
	require_once 'connect.php'; 
	
	if( isset($_POST['id']) ){
		
		$id=$_POST['id'];
		$query ="DELETE FROM cart_goods WHERE id = '$id'";
		$result = mysqli_query($link,$query);
		if ($result == true)
			echo "<script>history.go(-1)</script>";
		else
			echo "Произошла ошибка";
	}
	
	if(isset($_GET['deluser']))
	{
    $deluser=$_GET['deluser'];

	$query ="DELETE FROM users WHERE id_user = '$deluser'";
	$result = mysqli_query($link,$query);
    if ($result == true){
    echo "<script>history.go(-1)</script>";
    }else{
    	echo "Произошла ошибка";
    }
	}
	
?>