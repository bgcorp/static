<?php
	$title = "Моя корзина";
	include("layout/header.php");
?>


<?php
if( !isset($_SESSION["id_user"]) )
	header("location:sign_in.php");
?>



<div class="block_name"> В корзине </div>
<div class="goods_block">


<?php

$id_user=$_SESSION["id_user"];
$sum=0;
	
$query ="select * from cart_goods where id_user='$id_user'";

$result = mysqli_query($link, $query);

 while( $row = $result->fetch_assoc() ) { 

echo "<div class='goods_block_in_cart'>
				<p class='margin10 goods_name'> Товар: ".$row['name_goods']."</p>
				<p class='margin5 goods_price'> Цена: ".$row['price_goods']." тг</p>
				<form method='post'>
					<input type='hidden' name='id' value='".$row['id']."'>
					<input type='submit' class='button' formaction ='control/delete.php' value='Отменить'></form></div>";
				
	$sum=$sum+$row['price_goods'];
	$id=$row['id'];
	$date = $row['date'];

	$currentDate = strtotime($date);
	$futureDate = $currentDate+(60*5);
	$date1 = date("Y-m-d H:i:s", $futureDate);
	date_default_timezone_set('Asia/Almaty');
	$date2=date("Y-m-d G:i:s");


	/*
	if( strtotime($date1) < strtotime($date2) ) {
		$delete_query ="delete from cart_goods where id = '$id'";
		$delete_result = mysqli_query($link, $delete_query);
	} */
	
}
	date_default_timezone_set('Asia/Almaty');
	$date=date("Y-m-d G:i:s");
	echo "</div>";

	echo "<div class='goods_block_in_buy'><p class='margin5 goods_all_price'> К оплате ".$sum." тг</p>
	<form method='post'  action='control/buy.php'>
	<p class='margin10 goods_name'>Введите номер платежной карты: </p>
	<input name='id_card' type='number' min='4000000000000000' max='5999999999999999' class='input_text_card' required/>
	<input type='hidden' name='sum' value='".$sum."'>
	<input type='hidden' name='date' value='".$date."'>
	<input type='submit' class='button' value='Купить'></form></div>";
	
	
    mysqli_free_result($result);
?>


</div>



 <?php
	include("layout/footer.php");
?>