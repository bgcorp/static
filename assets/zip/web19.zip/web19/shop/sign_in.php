<?php	session_start();
	if( isset($_SESSION['id_user']) )
		header("location: index.php");
?>


<!doctype html>
<html lang="ru">
<head>
	<title>Shop | Вход </title>

	<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

	<link rel="stylesheet" type="text/css" href="css/login.css">
	
	<link rel="icon" href="image/logo.ico" type="image/x-icon">

</head>
<body>

<div class='sign_in' id='sign_in'>
	<div class='div_logo'> Shop </div>
	
<form method="POST">
	<div class='div_input'>
		<input type="text" name="email" class="pole" placeholder="Email" id="email" required autofocus/>
	</div>

	<div class='div_input'>
		<input type="password" name="password" class="pole" placeholder="Пароль" id="password" required/>
	</div>
 
	<div class='div_input'>
		<button class="button" type="button" id="btn_sign_in">Войти</button>
	</div>
</form>


  <div class='div_oth'>
  <p>Еще нет аккаунта? <a href="sign_up.php"> Зарегистрируйтесь </a></p>
  <p> <a href="index.php"> На главную страницу </a></p>
  </div>


  <div class='div_oth' id='incorrect'>Неверный емаил или пароль</div>
  
<div class="spinner">
	<div class="bounce1"></div>
	<div class="bounce2"></div>
	<div class="bounce3"></div>
</div>

<div class="process"><div class="process_spinner">
  <div class="bounce1"></div>
  <div class="bounce2"></div>
  <div class="bounce3"></div>
</div></div>

</div>



<script type="text/javascript" src="js/jquery-3.3.1.min.js"></script>
<script type="text/javascript" src="js/login.js"></script>

 </body>
</html>