﻿<?php
	$title = "Поиск товара";
	include("layout/header.php");
?>


<?php

	$category=$_GET['category'];
	
	echo "<div class='block_name'> Показана категория ".$category." </div> <div class='goods_block'>";

	$select_query ="SELECT * FROM goods where category_goods='$category'";
	$select_result = mysqli_query($link, $select_query) ;

	$count = 0;
	while( $row = $select_result->fetch_assoc() ) {
		
		date_default_timezone_set('Asia/Almaty');
		$date=date("Y-m-d G:i:s");
		echo "
			<input type='hidden' id='id_goods".$count."' value='".$row['id_goods']."'>
			<input type='hidden' id='date".$count."' value='".$date."'>
			<div class='goods_block_in'>
				<img src='".$row['image']."' width='190' height='190'>
				<p class='margin10 goods_name'>".$row['name_goods']."</p>
				<p class='margin5 goods_price'>" .$row['price_goods']." тг</p>
				<p class='margin5'><button class='button'  id='btn".$count."' > В корзину </button></p></div>";
		$count++;
    }
	
		mysqli_free_result($select_result);

?>
</div>
</div>

<script type="text/javascript">

for(var i = 0; i < <?php echo $count; ?>; i++){
	
	btn = document.getElementById("btn"+i);
    btn.onclick = (function(index) {
		<?php if( isset($_SESSION["id_user"]) ) { ?>		
        return function(){
			$.ajax({
			url: "control/cart.php?id_goods="+$('#id_goods'+index).val()+"&date="+$('#date'+index).val(),
			error: function() {
				console.log('Неполадки сетью'); },
			success: function(response) {
				$('#cartcount').html(response); }
			});
		};
		<?php } ?>
    })(i);

	
}

</script>



 <?php
	include("layout/footer.php");
?>