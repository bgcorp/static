<?php
	$title = "Страница администратора";
	include("layout/header.php");
?>


<?php
if( !isset($_SESSION["id_user"]) )
	header("location:sign_in.php");
?>

<?php 
	date_default_timezone_set('Asia/Almaty');
	$date=date(" G:i d.m.Y");
?>

<div class="block_name"> Статистика продажи товаров </div>
<div class="text_align"> <?php echo "Данные на дату".$date; ?> </div>


<?php
	
$s=0;
$select_cart_query ="select price from sold_goods";
$select_cart_result = mysqli_query($link, $select_cart_query) ;

while( $row = $select_cart_result->fetch_assoc() ) {
	$s+=$row['price'];
}

echo "<div class='div_statistics'> Продано товаров на сумму: ".$s." тенге </div>";
mysqli_free_result($select_cart_result);

$select_cart_query ="select count(price) from sold_goods";
$select_cart_result = mysqli_query($link, $select_cart_query) ;
$row=mysqli_fetch_array($select_cart_result);

echo "<div class='div_statistics'>Количество проданных товаров: ".$row[0]."</div>"; 
mysqli_free_result($select_cart_result);

$select_cart_query ="select count(distinct price) from sold_goods";
$select_cart_result = mysqli_query($link, $select_cart_query);
$row=mysqli_fetch_array($select_cart_result);

echo "<div class='div_statistics'>Количество проданных видов товара: ".$row[0]."</div>"; 
mysqli_free_result($select_cart_result);


$select_cart_query ="select distinct name_goods from cart_goods";
$select_cart_result = mysqli_query($link, $select_cart_query) ;

echo "<div class='div_statistics'>Товары: ";
while( $row = $select_cart_result->fetch_assoc() ) {
	echo $row['name_goods']." "."/ ";
}
echo "</div>";

mysqli_free_result($select_cart_result);


$select_user_query ="select * from users where status!='admin'";
$select_user_result = mysqli_query($link, $select_user_query) ;

echo "<div class='block_name'> Пользователи сайта </div> <div class='div_users'>

	<table >
		<thead>
			<tr>
				<td>Имя</td>
				<td>Фамилия</td>
				<td>Email</td>
				<td>Пароль</td>
				<td>Удалить</td>
			</tr>
		</thead><tbody>";
while( $row = $select_user_result->fetch_assoc() ) {
	
	$id_user_delete=$row['id_user'];
	echo "<tr>
					<td>".$row['firstname']."</td>
					<td>".$row['lastname']."</td>
					<td>".$row['email']."</td>
					<td>".$row['password']."</td>
					<td><form method='get' action='control/delete.php'><input type='hidden' name='deluser' value='$id_user_delete'/>
						<input type='submit' value='Удалить' class='button'/></form></td>
			</tr>";
}
echo "</tbody></table></div>";
mysqli_free_result($select_user_result);


?>


 <?php
	include("layout/footer.php");
?>