-- phpMyAdmin SQL Dump
-- version 4.8.5
-- https://www.phpmyadmin.net/
--
-- Хост: 127.0.0.1
-- Время создания: Дек 17 2019 г., 09:13
-- Версия сервера: 10.1.38-MariaDB
-- Версия PHP: 7.3.2

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- База данных: `shop`
--

-- --------------------------------------------------------

--
-- Структура таблицы `cart_goods`
--

CREATE TABLE `cart_goods` (
  `id` int(11) NOT NULL,
  `id_user` int(11) NOT NULL,
  `name_goods` varchar(50) NOT NULL,
  `price_goods` int(11) NOT NULL,
  `date` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Структура таблицы `goods`
--

CREATE TABLE `goods` (
  `id_goods` int(11) NOT NULL,
  `name_goods` varchar(50) NOT NULL,
  `price_goods` int(11) NOT NULL,
  `category_goods` varchar(50) NOT NULL,
  `image` varchar(50) NOT NULL DEFAULT 'image/phone.png'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `goods`
--

INSERT INTO `goods` (`id_goods`, `name_goods`, `price_goods`, `category_goods`, `image`) VALUES
(1, 'Samsung Galaxy A20', 20990, 'Смартфоны', 'image/phone.png'),
(2, 'Samsung Galaxy A50', 50000, 'Смартфоны', 'image/a50.png'),
(3, 'Samsung Galaxy A70', 59990, 'Смартфоны', 'image/a70.png'),
(4, 'Samsung Galaxy A80', 62000, 'Смартфоны', 'image/a80.png'),
(5, 'Samsung Galaxy S10', 89000, 'Смартфоны', 'image/s10.png'),
(6, 'iPhone XS', 79990, 'Смартфоны', 'image/ixs.png'),
(7, 'iPhone 11', 89000, 'Смартфоны', 'image/i11.png'),
(8, 'Xiaomi Redmin Note 8', 52000, 'Смартфоны', 'image/x8.png'),
(9, 'Lenovo Legion Y630', 60990, 'Компьютеры', 'image/leg1.png'),
(10, 'Lenove iDeaPad Y210', 50000, 'Компьютеры', 'image/ide1.png'),
(11, 'Asus Laptop X330', 52000, 'Компьютеры', 'image/asusx1.png'),
(12, 'MacBook Pro', 89000, 'Компьютеры', 'image/mac.png');

-- --------------------------------------------------------

--
-- Структура таблицы `sold_goods`
--

CREATE TABLE `sold_goods` (
  `id` int(11) NOT NULL,
  `id_user` int(11) NOT NULL,
  `price` int(11) NOT NULL,
  `card` int(16) NOT NULL,
  `date` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Структура таблицы `users`
--

CREATE TABLE `users` (
  `id_user` int(11) NOT NULL,
  `firstname` varchar(50) NOT NULL,
  `lastname` varchar(50) NOT NULL,
  `email` varchar(50) NOT NULL,
  `password` varchar(50) NOT NULL,
  `status` varchar(6) NOT NULL DEFAULT 'klient'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `users`
--

INSERT INTO `users` (`id_user`, `firstname`, `lastname`, `email`, `password`, `status`) VALUES
(1, '1', '1', '1', '1', 'klient'),
(2, '2', '2', '2', '2', 'klient'),
(3, '7', '7', '7', '7', 'admin');

--
-- Индексы сохранённых таблиц
--

--
-- Индексы таблицы `cart_goods`
--
ALTER TABLE `cart_goods`
  ADD PRIMARY KEY (`id`);

--
-- Индексы таблицы `goods`
--
ALTER TABLE `goods`
  ADD PRIMARY KEY (`id_goods`);

--
-- Индексы таблицы `sold_goods`
--
ALTER TABLE `sold_goods`
  ADD PRIMARY KEY (`id`);

--
-- Индексы таблицы `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id_user`),
  ADD UNIQUE KEY `email` (`email`);

--
-- AUTO_INCREMENT для сохранённых таблиц
--

--
-- AUTO_INCREMENT для таблицы `cart_goods`
--
ALTER TABLE `cart_goods`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT для таблицы `goods`
--
ALTER TABLE `goods`
  MODIFY `id_goods` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- AUTO_INCREMENT для таблицы `sold_goods`
--
ALTER TABLE `sold_goods`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT для таблицы `users`
--
ALTER TABLE `users`
  MODIFY `id_user` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
